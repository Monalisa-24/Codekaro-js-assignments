// create an empty object called "Person"
let person = {};

// add the following property 
person.name = "John";
person.age = 30;
person.city = "New York";

console.log(person);

// remove the "age" property
delete person.age;

// add a new property called "job" with the value "Engineer"
person.job = "Engineer";

// update the "city" property to "San Francisco"
person.city = " San Fransisco"; 

console.log(person);
